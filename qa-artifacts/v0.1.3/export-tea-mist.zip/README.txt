這是由 StoreSite Builder 產生的靜態網站。
請將 index.html 與 assets 資料夾一起上傳到任何靜態網站主機。
若要修改內容，請回到 StoreSite Builder 匯入 siteData.json 編輯後重新匯出。